import java.util.Scanner;

public class MovieDriver {

	public static void main(String[] args) {
		String answer;
		do {
		Scanner input = new Scanner (System.in);
		String title = new String();
		String rating = new String();
		String soldTickets = new String();
		
		
		System.out.println("Enter the title of a movie: ");
		title = input.nextLine();
		
		System.out.println("Enter the movie's rating: ");
		rating = input.nextLine();
		
		System.out.println("Enter the number of tickets sold for this movie: ");
		soldTickets = input.nextLine();
		
		System.out.println(title.toString() + 
				" (" + rating.toString() + "): Tickets Sold: " + soldTickets.toString());
		
		System.out.println("Do you want to enter another? (y or n)");
		answer = input.nextLine();
		}
		while (answer.contentEquals("y"));
		
		System.out.println("Goodbye");
	}

}
